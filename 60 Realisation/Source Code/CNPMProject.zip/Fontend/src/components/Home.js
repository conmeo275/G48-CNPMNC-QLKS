import React from 'react';


export class Home extends React.Component {


  render() {
    return (
      <div className="mt-5 justify-content-center">
      <h3 className="mt-3 d-flex justify-content-center">
    ReactJS with NodeJS Demo</h3>
    <h5 className="mt-3 d-flex justify-content-center">
    Hotel Management</h5>
      </div>
    );
  }
}

export default Home;
